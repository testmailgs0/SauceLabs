package saucedemo.TestAutomation.TestData;

public class ApplicationArguments {

	private String siteURL = "https://www.saucedemo.com/";
	private String sitePass = "standard_user";
	private String siteUser = "secret_sauce";
	private String prdPgeURL= "https://www.saucedemo.com/inventory.html";
	private String crtPageURL= "https://www.saucedemo.com/cart.html";
	private String checkoutPge = "https://www.saucedemo.com/checkout-step-one.html";
	private String checkOutOverview = "https://www.saucedemo.com/checkout-step-two.html";

	public String getCheckOutOverview() {
		return checkOutOverview;
	}

	public void setCheckOutOverview(String checkOutOverview) {
		this.checkOutOverview = checkOutOverview;
	}

	public String getCheckoutPge() {
		return checkoutPge;
	}

	public void setCheckoutPge(String checkoutPge) {
		this.checkoutPge = checkoutPge;
	}

	public String getCrtPageURL() {
		return crtPageURL;
	}

	public void setCrtPageURL(String crtPageURL) {
		this.crtPageURL = crtPageURL;
	}

	public String getPrdPgeURL() {
		return prdPgeURL;
	}

	public void setPrdPgeURL(String prdPgeURL) {
		this.prdPgeURL = prdPgeURL;
	}

	public String getSiteURL() {
		return siteURL;
	}

	public void setSiteURL(String siteURL) {
		this.siteURL = siteURL;
	}

	public String getSitePass() {
		return sitePass;
	}

	public void setSitePass(String sitePass) {
		this.sitePass = sitePass;
	}

	public String getSiteUser() {
		return siteUser;
	}

	public void setSiteUser(String siteUser) {
		this.siteUser = siteUser;
	}


}
