package saucedemo.TestAutomation.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CartPage {
    public WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(how = How.ID, using = "checkout")
    public WebElement checkOut;

    @FindBy(how = How.XPATH, using = "//a[@class='shopping_cart_link']")
    public WebElement cartBtn;

    public boolean fnVerifyCartPage(String pageUrl) throws Exception {
        return driver.getCurrentUrl().equalsIgnoreCase(pageUrl);
    }

    public void fnOpenCart() throws Exception {
        cartBtn.click();
    }

    public void fnCheckout() throws Exception {
        checkOut.click();
    }
}
