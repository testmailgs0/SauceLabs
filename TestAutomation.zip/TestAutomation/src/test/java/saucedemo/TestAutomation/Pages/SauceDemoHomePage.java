package saucedemo.TestAutomation.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SauceDemoHomePage {
	public WebDriver driver;
	
	public SauceDemoHomePage(WebDriver driver)
	{
		this.driver = driver;
	}

	@FindBy(how = How.ID, using = "user-name")
	public WebElement userName;

	@FindBy(how = How.ID, using = "password")
	public WebElement userPass;

	@FindBy(how = How.ID, using = "login-button")
	public WebElement userLoginbtn;

	public void Login(String user, String pass) throws Exception {
		userName.sendKeys(user);
		userPass.sendKeys(pass);
		userLoginbtn.click();
	}

}
