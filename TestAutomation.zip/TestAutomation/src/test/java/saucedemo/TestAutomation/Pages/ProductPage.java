package saucedemo.TestAutomation.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class ProductPage {
	public WebDriver driver;

	public ProductPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how = How.ID, using = "react-burger-menu-btn")
	public WebElement burgerMenu;

	@FindBy(how = How.XPATH, using = "//select")
	public WebElement dropDown;

	public void fnOpenBugerMenu() throws Exception {
		burgerMenu.click();
	}

	public void fnSelectItemWithHighestPrice() throws Exception{
		Select valueSelector = new Select(dropDown);
		valueSelector.selectByIndex(3);
		driver.findElements(By.xpath("//button[@class='btn btn_primary btn_small btn_inventory']")).get(0).click();
	}
	
	public void fnOpenCart() throws Exception
	{
		driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
	}
}
