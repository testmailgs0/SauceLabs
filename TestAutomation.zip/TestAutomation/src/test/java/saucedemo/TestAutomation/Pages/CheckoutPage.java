package saucedemo.TestAutomation.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CheckoutPage {
	public WebDriver driver;

	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how = How.ID, using = "first-Name")
	public WebElement firstName;

	@FindBy(how = How.ID, using = "last-Name")
	public WebElement lastName;

	@FindBy(how = How.ID, using = "postal-code")
	public WebElement postalCode;

	@FindBy(how = How.ID, using = "continue")
	public WebElement contBtn;

	public boolean fnVerifyCheckOutPage(String pageUrl) throws Exception {
		return driver.getCurrentUrl().equalsIgnoreCase(pageUrl);
	}

	public void fnEnterUserInfo(String firstnm, String lstnm, String pstcd) throws Exception {
		firstName.sendKeys(firstnm);
		lastName.sendKeys(lstnm);
		postalCode.sendKeys(pstcd);
		contBtn.click();
	}

	public boolean fnVerifyInventoryItemPrice(String val) {
		val.replace('$', ' ');
		int valNew = Integer.parseInt(val);
		if (valNew % 1 == 0)
			return true;
		else
			return false;
	}
}
