package saucedemo.TestAutomation.Tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.*;

import org.testng.asserts.SoftAssert;
import saucedemo.TestAutomation.Pages.CartPage;
import saucedemo.TestAutomation.Pages.CheckoutPage;
import saucedemo.TestAutomation.Pages.ProductPage;
import saucedemo.TestAutomation.Pages.SauceDemoHomePage;
import saucedemo.TestAutomation.TestData.ApplicationArguments;

public class Sauce_UI_Validation {

    public WebDriver driver;

    @SuppressWarnings("deprecation")
    @BeforeClass
    public void Setup() {
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    @Test
    public void ExecuteTest() throws Exception {
        ApplicationArguments data = new ApplicationArguments();
        driver.get(data.getSiteURL().toString());
        SauceDemoHomePage _obj = PageFactory.initElements(driver, SauceDemoHomePage.class);
        _obj.Login(data.getSiteUser().toString(), data.getSitePass().toString());
        //code for clicking burgermenu
        ProductPage _prdobj = PageFactory.initElements(driver, ProductPage.class);
        _prdobj.fnOpenBugerMenu();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//a[@id='about_sidebar_link']")).click();
        if (driver.getCurrentUrl().equalsIgnoreCase("https://saucelabs.com/")) {
            System.out.println("URL Verification Passed");
        } else {
            System.out.println("URL Verification Failed");
        }
        driver.navigate().back();
        _prdobj.fnSelectItemWithHighestPrice();
        if (driver.getCurrentUrl().equalsIgnoreCase(data.getPrdPgeURL())) {
            System.out.println("Product URL Verification Passed");
        } else {
            System.out.println("Product URL Verification Failed");
        }
        CartPage crtObj = PageFactory.initElements(driver, CartPage.class);
        new SoftAssert().assertEquals(crtObj.fnVerifyCartPage(data.getCrtPageURL()), true);
        crtObj.fnOpenCart();
        Thread.sleep(1000);
        crtObj.fnCheckout();
        Thread.sleep(4000);
        CheckoutPage chkpgobj = PageFactory.initElements(driver, CheckoutPage.class);
        new SoftAssert().assertEquals(chkpgobj.fnVerifyCheckOutPage(data.getCheckoutPge()), true);
        chkpgobj.fnEnterUserInfo("karan", "prakash", "110058");
        new SoftAssert().assertEquals(driver.getCurrentUrl(), data.getCheckOutOverview());
        new SoftAssert().assertEquals(chkpgobj.fnVerifyInventoryItemPrice(driver.findElement(By.xpath("//div[@class='inventory_item_price']")).getText()), true);
    }


    @AfterTest
    public void Exit() {
        driver.quit();
    }
}
