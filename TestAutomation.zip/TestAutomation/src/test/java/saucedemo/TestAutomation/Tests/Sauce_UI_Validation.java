package saucedemo.TestAutomation.Tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import saucedemo.TestAutomation.Pages.CartPage;
import saucedemo.TestAutomation.Pages.CheckoutPage;
import saucedemo.TestAutomation.Pages.ProductPage;
import saucedemo.TestAutomation.Pages.SauceDemoHomePage;
import saucedemo.TestAutomation.TestData.ApplicationArguments;

public class Sauce_UI_Validation {
	
public WebDriver driver;	
	
	@SuppressWarnings("deprecation")
	@BeforeClass
	public void Setup()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Test_03_01_22\\TestAutomation\\chromedriver_win32");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	}
	
	@Test
	public void ExecuteTest() throws Exception
	{
		ApplicationArguments data = new ApplicationArguments();
		driver.get(data.getSiteURL().toString());
		SauceDemoHomePage _obj = PageFactory.initElements(driver, SauceDemoHomePage.class);
		_obj.Login(data.getSiteUser().toString(), data.getSitePass().toString());
		//code for clicking burgermenu
		ProductPage _prdobj = PageFactory.initElements(driver, ProductPage.class);
		_prdobj.fnOpenBugerMenu();
		driver.findElements(By.xpath("//a[@class='bm-item menu-item']")).get(0).click();
		if (driver.getCurrentUrl().equalsIgnoreCase(data.getSiteURL()))
		{
			System.out.println("URL Verification Passed");
		}
		else 
		{
			System.out.println("URL Verification Failed");
		}
		driver.navigate().back();
		if (driver.getCurrentUrl().equalsIgnoreCase(data.getPrdPgeURL()))
		{
			System.out.println("Product URL Verification Passed");
		}
		else 
		{
			System.out.println("Product URL Verification Failed");
		}
		CartPage crtObj = PageFactory.initElements(driver, CartPage.class);
		Assert.assertEquals(crtObj.fnVerifyCartPage(data.getCrtPageURL()),true);
		crtObj.fnCheckout();
		CheckoutPage chkpgobj = PageFactory.initElements(driver, CheckoutPage.class);
		Assert.assertEquals(chkpgobj.fnVerifyCheckOutPage(data.getCheckoutPge()),true);
		chkpgobj.fnEnterUserInfo("karan", "prakash", "110058");
		Assert.assertEquals(driver.getCurrentUrl(), data.getCheckOutOverview());
		Assert.assertEquals(chkpgobj.fnVerifyInventoryItemPrice(driver.findElement(By.xpath("//div[@class='inventory_item_price']")).getText()), true);
	}
}
